<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="Estilos/items.css">
    <link rel="icon" type="image/png" href="vista/Estilos/Images/7671093.png">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <title>Pelispedia | Actores</title>
</head>

<body>
    <nav>
        <ul>
            <li><a href="inicio.html">Volver</a></li>
        </ul>
    </nav>
    <center><img src="Estilos/Images/Pelispedia.png" alt="logo"></center>
    <div class="formulario">
        <?php
        include "C:/xampp/htdocs/MVC/controlador/actorController.php";
        tablaActores();
        ?>
        <div class="container">
            <form class="form-group" method="POST">
                <label>ID:</label><br>
                <input type="text" id="id" name="id" readonly><br><br>
                <label>Nombre:</label><br>
                <input type="text" id="nombre" name="nombre"><br><br>
                <label>Apellido:</label><br>
                <input type="text" id="apellido" name="apellido"><br><br>
                <button type="submit" name="agregar">Agregar</button>
                <button type="submit" name="modificar">Modificar</button>
                <button type="submit" name="eliminar">Eliminar</button>
            </form>
        </div>
    </div>
    <footer>
        <center>
            <p>© [2023] Juan Camilo Hurtado A. Todos los derechos reservados.</p>
        </center>
    </footer>
</body>

</html>