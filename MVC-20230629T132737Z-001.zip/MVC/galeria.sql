-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 13-06-2023 a las 05:10:57
-- Versión del servidor: 10.4.25-MariaDB
-- Versión de PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `galeria`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `actor`
--

CREATE TABLE `actor` (
  `act_id` int(11) NOT NULL,
  `act_nombre` varchar(100) NOT NULL,
  `act_apellido` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `actor`
--

INSERT INTO `actor` (`act_id`, `act_nombre`, `act_apellido`) VALUES
(1, 'Robert', 'De Niro'),
(2, 'Marcello ', 'Mastroianni'),
(3, 'Anthony', 'Perkins'),
(4, 'Uma', 'Thurman'),
(5, 'Bruno', 'Zanin'),
(6, 'Malcolm', 'McDowell');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `director`
--

CREATE TABLE `director` (
  `dir_id` int(11) NOT NULL,
  `dir_nombre` varchar(100) NOT NULL,
  `dir_nacionalidad` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `director`
--

INSERT INTO `director` (`dir_id`, `dir_nombre`, `dir_nacionalidad`) VALUES
(1, 'Martin Scorsese', 'Estados Unidos'),
(2, 'Steven Spielberg ', 'Estados Unidos'),
(3, 'Quentin Tarantino', ' Estados Unidos'),
(4, 'Alfred Hitchcock', ' Reino Unido'),
(5, 'Stanley Kubrick', 'Estados Unidos'),
(6, 'Federico Fellini', 'Italia');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `participacion`
--

CREATE TABLE `participacion` (
  `part_id` int(11) NOT NULL,
  `peli_id` int(11) NOT NULL,
  `act_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `participacion`
--

INSERT INTO `participacion` (`part_id`, `peli_id`, `act_id`) VALUES
(1, 1, 1),
(2, 2, 1),
(3, 12, 2),
(4, 7, 3),
(5, 9, 3),
(6, 5, 4),
(7, 6, 4),
(8, 11, 5),
(9, 10, 6);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pelicula`
--

CREATE TABLE `pelicula` (
  `peli_id` int(11) NOT NULL,
  `peli_titulo` varchar(100) NOT NULL,
  `dir_id` int(11) NOT NULL,
  `peli_anio_lanzamiento` int(11) NOT NULL,
  `link_img` varchar(500) DEFAULT NULL,
  `peli_bg` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `pelicula`
--

INSERT INTO `pelicula` (`peli_id`, `peli_titulo`, `dir_id`, `peli_anio_lanzamiento`, `link_img`, `peli_bg`) VALUES
(1, 'Taxi Driver', 1, 1976, 'https://www.efeeme.com/wp-content/uploads/taxi-driver-10-06-12-b.jpg', 'https://wallpapercave.com/wp/wp1878240.jpg'),
(2, 'Goodfellas', 1, 1990, 'https://http2.mlstatic.com/D_NQ_NP_612747-MCO46421568797_062021-O.webp', 'https://images7.alphacoders.com/341/thumb-1920-341191.jpg'),
(3, 'Jurassic Park', 2, 1993, 'https://http2.mlstatic.com/D_NQ_NP_712528-MCO46411326382_062021-O.jpg', 'https://c4.wallpaperflare.com/wallpaper/626/102/458/1993-year-jurassic-park-dinosaurs-movies-car-hd-wallpaper-preview.jpg'),
(4, 'E.T. the Extra-Terrestrial', 2, 1982, 'https://i.pinimg.com/originals/78/14/29/781429f191a943d68b8d8e9180bce406.jpg', 'https://wallpaperaccess.com/full/1898037.jpg'),
(5, 'Pulp Fiction', 3, 1994, 'https://img1.wsimg.com/isteam/ip/e72bcd39-f5cf-4697-9d95-35482c84ddc3/3DEC48CB-885C-45A7-B0DC-13571A69F3F5.jpeg', 'https://images2.alphacoders.com/867/thumb-1920-86710.jpg'),
(6, 'Kill Bill: Volume 1', 3, 2003, 'https://cdn.shopify.com/s/files/1/0057/3728/3618/products/KILLBILL.VOL.1.PW_500x.jpg?v=1574966219', 'https://images.alphacoders.com/385/thumb-1920-3853.jpg'),
(7, 'Psycho', 4, 1960, 'https://i.pinimg.com/originals/7f/5f/ec/7f5fec16a1e9fac3c64ca1ddbd14e969.jpg', 'https://images4.alphacoders.com/810/thumb-1920-810011.jpg'),
(8, 'Vertigo', 4, 1958, 'https://upload.wikimedia.org/wikipedia/commons/7/75/Vertigomovie_restoration.jpg', 'https://c4.wallpaperflare.com/wallpaper/751/996/908/movie-vertigo-wallpaper-preview.jpg'),
(9, 'The Shining', 5, 1980, 'https://resizing.flixster.com/exiIk4Tzwlc6unOZGkJH-8BXLpQ=/206x305/v2/https://flxt.tmsimg.com/assets/p40_p_v8_ar.jpg', 'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBUVFRgWFhUYGBgYHBoYHBgZHBoaGhwaGhwaGhoaGBocIS4lHCErIRoYJjgmKy8xNTU1GiQ7QDs0Py40NTEBDAwMEA8QHxISGjQhJCE0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIAKgBLAMBIgACEQEDEQH/xAAaAAACAwEBAAAAAAAAAAAAAAADBAACBQEG/8QAOxAAAQMCAwYGAQIEBQUBAQAAAQACEQMhBDFBElFhcYGRBSKhscHwMtHhE3KC8SNCUmLCFBWSstKiBv/EABkBAAMBAQEAAAAAAAAAAAAAAAABAgMEBf/EACIRAQEAAwEAAgICAwAAAAAAAAABAhExIRJBA1EEYRQiMv/aAAwDAQACEQMRAD8A8xh36EZtn0ujvqh7Nxvbl9CVf'),
(10, 'A Clockwork Orange', 5, 1971, 'https://m.media-amazon.com/images/I/71TUj3olRXL.jpg', 'https://cdn.wallpapersafari.com/2/17/m80Dk9.jpg'),
(11, 'Amarcord', 6, 1973, 'https://i.pinimg.com/originals/23/0e/e7/230ee75298d5863ac9c8cfa846b8e4ce.jpg', 'https://atypical60.com/wp-content/uploads/2015/10/amarcord-poster.jpg'),
(12, 'La Dolce Vita', 6, 1960, 'https://spirossoutsos.com/wp-content/uploads/2016/02/La_Dolce_vita_fellini-federico-movi-poster-painting.jpg', 'https://wallpapercave.com/wp/wp9498741.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `usu_nombre` varchar(15) NOT NULL,
  `usu_apellidos` varchar(15) DEFAULT NULL,
  `usu_email` varchar(30) NOT NULL,
  `usu_password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`usu_nombre`, `usu_apellidos`, `usu_email`, `usu_password`) VALUES
('', '', '', '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `actor`
--
ALTER TABLE `actor`
  ADD PRIMARY KEY (`act_id`);

--
-- Indices de la tabla `director`
--
ALTER TABLE `director`
  ADD PRIMARY KEY (`dir_id`);

--
-- Indices de la tabla `participacion`
--
ALTER TABLE `participacion`
  ADD PRIMARY KEY (`part_id`),
  ADD KEY `peli_id` (`peli_id`),
  ADD KEY `act_id` (`act_id`);

--
-- Indices de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  ADD PRIMARY KEY (`peli_id`),
  ADD KEY `dir_id` (`dir_id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`usu_email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `actor`
--
ALTER TABLE `actor`
  MODIFY `act_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT de la tabla `director`
--
ALTER TABLE `director`
  MODIFY `dir_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de la tabla `participacion`
--
ALTER TABLE `participacion`
  MODIFY `part_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT de la tabla `pelicula`
--
ALTER TABLE `pelicula`
  MODIFY `peli_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `participacion`
--
ALTER TABLE `participacion`
  ADD CONSTRAINT `participacion_ibfk_1` FOREIGN KEY (`peli_id`) REFERENCES `pelicula` (`peli_id`),
  ADD CONSTRAINT `participacion_ibfk_2` FOREIGN KEY (`act_id`) REFERENCES `actor` (`act_id`);

--
-- Filtros para la tabla `pelicula`
--
ALTER TABLE `pelicula`
  ADD CONSTRAINT `pelicula_ibfk_1` FOREIGN KEY (`dir_id`) REFERENCES `director` (`dir_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
