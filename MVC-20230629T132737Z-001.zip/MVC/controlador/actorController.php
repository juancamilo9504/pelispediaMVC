<?php
include 'C:\xampp\htdocs\MVC\modelo\Conexion.php';
include 'C:\xampp\htdocs\MVC\modelo\Actor.php';
function traerActor($conn, $id)
{
    $result = $conn->query('select * from actor where act_id = ' . $id);
    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $actor = new Actor($row["act_id"], $row["act_nombre"], $row["act_apellido"]);
        return $actor;
    } else {
        throw new Exception("Actor no encontrado");
    }
}
function traerActores($conn)
{
    $actores = array();
    for ($i = 1; ; $i++) {
        try {
            $actor = traerActor($conn, $i);
            array_push($actores, $actor);
        } catch (Exception $e) {
            break;
        }
    }
    return $actores;
}
function tablaActores()
{
    $lista = array();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "actoresmvc";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $database);

    // Verificar la conexión
    if ($conn->connect_error) {
        die("Error en la conexión: " . $conn->connect_error);
    }

    $result = $conn->query("SELECT * FROM actor");
    if ($result->num_rows > 0) {
        // Imprimir la tabla
        echo "<table>";
        echo "<tr>";
        echo "<th>ID</th>";
        echo "<th>Nombre</th>";
        echo "<th>Apellido</th>";
        echo "</tr>";

        // Iterar sobre los resultados y mostrarlos en la tabla
    
    echo "<script src='controlador/actorController.js'></script>";
        while ($row = $result->fetch_assoc()) {
            $id = $row["act_id"];
            $nombre = $row["act_nombre"];
            $apellido = $row["act_apellido"];
            echo "<div class='registro'>";
            echo "<tr onclick='llenarCajasTexto($id, \"$nombre\", \"$apellido\")'>";
            echo "<td>" . $id . "</td>";
            echo "<td>" . $nombre . "</td>";
            echo "<td>" . $apellido . "</td>";
            echo "</tr></div>";
        }

        echo "</table>";
    } else {
        echo "No se encontraron registros.";
    }

    // Cerrar la conexión
    $conn->close();
}
//Agregar actor
if (isset($_POST["agregar"])) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "actoresmvc";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $database);

    $id = $_POST['id'];
    $nombre = $_POST['nombre'];
    $apellido = $_POST['apellido'];

    // Verificar si los datos ya existen en la base de datos
    $query = "SELECT * FROM actor WHERE act_id = '$id' AND act_nombre = '$nombre' AND act_apellido = '$apellido'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 0) {
        // Insertar los datos en la base de datos
        $sql = "INSERT INTO `actor`(`act_id`, `act_nombre`, `act_apellido`) VALUES ('$id','$nombre','$apellido')";
        mysqli_query($conn, $sql);
        // Redireccionar a la misma página después de la inserción
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        // Datos duplicados, mostrar mensaje de error o realizar otra acción
        echo "Los datos ya existen en la base de datos.";
    }

    $conn->close();
}
// Modificar un actor existente
if (isset($_POST["modificar"])) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "actoresmvc";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $database);
    $id = $_POST["id"];
    $nombre = $_POST["nombre"];
    $apellido = $_POST["apellido"];

    $sql = "UPDATE actor SET act_nombre='$nombre', act_apellido='$apellido' WHERE act_id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Registro modificado correctamente.";
        // Redireccionar a la misma página después de la modificación
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error al modificar el registro: " . $conn->error;
    }
    $conn->close();
}

// Eliminar un actor
if (isset($_POST["eliminar"])) {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "actoresmvc";

    // Crear la conexión
    $conn = new mysqli($servername, $username, $password, $database);
    $id = $_POST["id"];

    $sql = "DELETE FROM actor WHERE act_id=$id";

    if ($conn->query($sql) === TRUE) {
        echo "Registro eliminado correctamente.";
        // Redireccionar a la misma página después de la eliminación
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error al eliminar el registro: " . $conn->error;
    }
    $conn->close();
}
echo '<script>
        function llenarCajasTexto(id, nombre, apellido) {
            document.getElementById("id").value = id;
            document.getElementById("nombre").value = nombre;
            document.getElementById("apellido").value = apellido;
        }
    </script>';
?>